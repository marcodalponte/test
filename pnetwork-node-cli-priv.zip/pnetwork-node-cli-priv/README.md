# pCLI - pNetwork client
The pCLI is the command-line interface for creating, editing and interacting with a pnode on pNetwork.
Used from your local machine, the pCLI will be able to create and manage your pNetwork nodes and bridges, interact with the bridges' components, edit the instances details and much more!
Currently supported on Linux, MacOS and Windows (WSL [link to WSL steps]) - no dependencies are needed and all the configuration will be created by the user, via prompt.

## Prerequisites
* An AWS active account [link to AWS docs for basic account creation]
* AWS `ACCOUNT_ID` and `SECRET_ID` (either manually input them or set them as ENV) [link to AWS steps to get `ACCOUNT_ID` and `SECRET_KEY`]

## Under the hood:
* python v3.7.9
* terraform v0.13.3
  * provider registry.terraform.io/hashicorp/aws v3.8.0
* ansible v2.9.13

## CLI overview

```
usage: pcli [-h] [-v]
            {backup,bridge,bridge-config,exec,node,restore,update} ...

positional arguments:
  {backup,bridge,bridge-config,exec,node,restore,update}
    backup              backup nodes states
    bridge              interact with bridge's components
    bridge-config       create/edit bridge .env file
    exec                exec command or script on pnetwork node
    node                interact with nodes
    restore             restore nodes states
    update              update pCLI

optional arguments:
  -h, --help            show this help message and exit
  -v                    show program's version number and exit
```

### `backup`:

```
usage: pcli backup [-h] -d

optional arguments:
  -h, --help         show this help message and exit
  -n                 node to backup
  -d                 backup destination path
```
* Backup active nodes' states file inside a given path (`node name`).
  * e.g., `pcli backup -n pbtc-on-eth-1 -d /home/<user>/pbtc-on-eth-1-bak`

### `bridge`:

```
usage: pcli bridge [-h]
                   {up,ps,stop,restart}
                   {api,syncer_native,syncer_host,tx_broadcaster,all}

positional arguments:
  {up,ps,stop,restart}     specify action
  {api,syncer_native,syncer_host,tx_broadcaster,all}
                        specify component

optional arguments:
  -h, --help            show this help message and exit
  -n                    select node
```
* Interact with bridges' components.
  e.g.:
  * `pcli bridge -n pbtc-on-eth-1 start api` to manage a single bridge's component
  or
  * `pcli bridge -n pbtc-on-eth-1 restart all` to manage all the components

### `bridge-config`:

```
usage: pcli bridge-config [-h] -n -b [-e [...]]

optional arguments:
  -h, --help           show this help message and exit
  -n                   select node
  -b                   bridge_name
  -e  [ ...]           edit a .env file on the given bridge
```
* Create configuration file for the first run of a bridge (`pcli bridge-config -n pbtc-on-eth-1 -b pbtc-on-eth`), edit a single var of a running bridge (`pcli bridge-config -n pbtc-on-eth-1 -b pbtc-on-eth -e var=value`) or edit a list of vars (`pcli bridge-config -n pbtc-on-eth-1 -b pbtc-on-eth -e var1=val1 var2=val2 ... varn=valn`) [link to editable vars list]

### `exec`:

```
usage: pcli exec [-h] -n  [-r] [-s]

optional arguments:
  -h, --help      show this help message and exit
  -n              select node where to run command/script
  -r              run command on node
  -s              run script on node
```
* Execute raw command or script remotely on node instance.

### `node`:

```
usage: pcli node [-h] [-n] {destroy,edit,list,provisioning,ssh, update}

positional arguments:
  {destroy,edit,list,provisioning,ssh, update}
                        specify action

optional arguments:
  -h, --help            show this help message and exit
  -n                    node's name
  -p                    package name (`all` for whole package)
  -a                    advance mode for provisioning
```
* Interact with nodes:
  * `pcli node provisioning`  -> `<random-name>` instance provisioning (via prompt)
  * `pcli node ssh -n pbtc-on-eth-1` -> ssh into new instance
  * `pcli node list` -> print all active nodes (format `name: pub_IP`)
  * `pcli node update -p pnode_dashboard -n pbtc-on-eth-1` -> update only `pnode_dashboard`
  * `pcli node edit -n pbtc-on-eth-1` -> edit one or more details of the instance (via prompt)
  * `pcli node destroy -n pbtc-on-eth-1` -> destroy each component of the instance and its related file on the user host 

### `restore`:

```
usage: pcli restore [-h] -i

optional arguments:
  -h, --help          show this help message and exit
  -i                  backup input path
```
* Restore nodes' states from backup. This command will move the backed-up node's state into the `~/.pcli` folder, in order to be detected and managed.
  * e.g., `pcli restore -i /home/<user>/pbtc-on-eth-1-bak`

### `update`:

```
usage: pcli update [-h]

optional arguments:
  -h, --help  show this help message and exit
```
* Check for new pCLI versions.

## Workflow
1. Run the instance provisioning with the command `pcli node provisioning` and follow the instructions in order to input the instance and node configuration files
2. Wait for the provisioning, setup, reboot and tuning of the instance
3. If needed, connect to the node with the command `pcli node ssh -n <node_name>`
4. Create the `.env` file (`pcli bridge-config -n <node_name> -b <bridge_type)`) before building and starting the needed node components
5. Run the bridge via `pcli bridge -n <node_name> start all`
6. Once the installation is finished, `pcli node list` can give a list of the active nodes
7. It will be also possible to edit every part of the instance, running `pcli node edit -n <node_name> -b <bridge_type> -e var1=val1 var2=val2`
8. .. or the bridge, running `pcli bridge-config -n <node_name> -b <bridge_type> -e var1=val1 var2=val2`
9. If, for any reason, the instance must be deleted, run `pcli node destroy -n <node_name>` to delete every resources related to the instance name (and states files in local path)

### ansible related files
* `ans_config.sys_conf` -> playbook to install, setup and update all the needed tools on the instance
* `ans_config.pnode` -> playbook to setup the environment for `nitro-enclave`
* `ans_config.edit_user_pwd` -> playbook to edit user pwd and enable ssh pwd-auth
* `ans_config.scp_logrotate` -> playbook to remote copy `logrotate` file in order to rotate all the pnode logs
* `ans_config.logs_duplicator` -> bash script which tails all the needed system logs into a specific folder, in order to securely expose them via nginx
* `ans_config.pnode_logs` -> pnode logrotate config file
* `ans_config.ans_cfg` -> ansible configuration file
* `ans_config.ptokens_bridge_verifier_mng` -> python wrapper of `ptokens-bridge-verifier` - it orchestrates the execution of the `bridge-verifier`

### terraform related files
* `tf_config.main_tf` -> contains the main steps to take
* `tf_config.variables_tf` -> contains the vars for `main.tf`
* `tf_config.output_tf` -> allows to set which output-var (created during the provisioning) will be saved (and where) - Useful to save the public IP of the instance we just created and make it usable for `ansible` and the py code.
* `state.tfstate` -> contains the actual state of the instance - critical file since it is needed to interact, edit and delete the instance

### pCLI logs
A log file will be created on the project root folder (`.pcli.log`)

#### Code modules:
* `ansible.py` -> ansible related functions
* `bridge.py` -> bridges management (docker commands and bridges configurations)
* `cli.py` -> `argparse`, `logging` and `main()`
* `node.py` -> node (and its components) related functions
* `terraform.py` -> `terraform` instance provisioning/update functions
* `utils.py` -> utilities functions, such as run commands, reboot the remote system, unzip, etc)

#### Config modules:
* `ans_config.py` -> ansible config module
* `client_config.py` -> contains pcli default paths and URLs
* `inst_config.py` -> instance configuration (this file will be edited dynamically in console)
* `tf_config.py` -> terraform config module

### Build `pcli` binary:
```
pyinstaller --onefile pcli.spec
```
Then package the `pcli` binary (and relative config files) inside `pcli-<version>.rpm`
